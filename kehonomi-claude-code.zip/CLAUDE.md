# Kehonomi Booking System — Claude Code Master Prompt

## Project Overview
Finnish health clinic booking system (SaaS). Single HTML file preview
showing the complete admin + client UI. Built for Kehonomi Oy (jani@kehonomi.fi).
Future: production build with Node.js/Supabase backend + license server.

## Current File
`kehonomi-v9.html` — the single source of truth (~210KB, ~4000 lines)

## Tech Stack
- Pure HTML/CSS/JS — no frameworks, no build step
- Fonts: Plus Jakarta Sans (headings 800-900), DM Sans (body)
- Validate JS with: `node -e "const fs=require('fs'),c=fs.readFileSync('kehonomi-v9.html','utf8');const s=c.lastIndexOf('<script>'),e=c.lastIndexOf('</script>');try{new Function(c.slice(s+8,e));console.log('OK');}catch(err){console.log('ERROR:',err.message);}"`
- ALWAYS validate before considering any change done
- NEVER rebuild from scratch — surgical edits only

## Design System (FROZEN — never change)
- Admin accent: Blue #2563eb / #1d4ed8
- Client view accent: Violet-to-blue gradient (#4c1d95 → #2563eb)
- Service cards: white floating, diagonal shadow upper-left highlight + lower-right depth
- Border radius: 16-22px cards, 10-14px buttons
- Shadows: soft diffused, not hard

## Architecture — 8 logical modules (all in one script tag)

### Data (engine_data section)
- `LOCATIONS[]` — multi-clinic support
- `EMP[]` — staff with photo, bio, specialities, rating
- `SVC[]` — services with duration, price, VAT, category
- `WBS[]` — work blocks (shifts) by empId + day-of-week
- `BKS[]` — bookings (SHARED between client and admin)
- `BREAKS[]` — break blocks (block slots from client booking)
- `CUSTS[]` — customer registry
- `SETTINGS` — cancelHours, breakMinutes, logoUrl, clientBgImage, etc.
- `LICENSE` — key, plan, expiresAt, maxUsers (stub — needs server in production)

### Slot Engine (engine_slots section)
- `getAvailableSlots(empId, dateKey, svcDur)` → real free slots
- `getDayColorClass(empId, dateKey)` → green/orange/red/no-slots
- `getAvailableMins(empId, dateKey)` → total free minutes
- `createBooking(data)` → pushes to BKS[], upserts CUSTS[]
- `cancelBooking(bkId, byClient)` → enforces cancelHours window
- `sendEmail(type, bk)` → console stub (wire to Resend/SendGrid)
- BREAKS[] are factored into slot availability

### Admin Calendar
- Dark-themed control bar: location chip + staff chip + privacy toggle
- Varaukset / Työvuorot tab strip
- Toiminnot dropdown (create shifts, copy week, delete week, print, etc.)
- 15-min grid: tcell-hour (15px bold) + tcell-qtr (15px dashed)
- Clicking empty slot → modal: "Uusi asiakasvaraus" or "⏸ Lisää tauko"
- Click booking tile → edit modal with custom 15-min time pickers
- Break tiles: diagonal-stripe grey, clickable to edit/delete
- Payment dots on tiles (green=paid, red=unpaid)
- Privacy mode: tiles show initials only

### Client Booking Flow (8 screens)
Location → Services → Therapist → TherapistDetail → Calendar → ClientDetails → Confirm → Confirmed
- Viewport-locked: desktop = phone frame (430px) on dark bg, mobile = 100dvh
- Services bg: violet gradient left → light right, floating white cards with diagonal shadows
- Calendar uses real slot engine — only shows genuinely free times
- AI chat: "En ole varma" → slides up, matches Finnish health keywords, recommends service
  - `AI_DEMO_MODE = true` — set false + `ANTHROPIC_API_KEY` for live
- Cancellation enforces SETTINGS.cancelHours from confirmation screen

### Custom Time Pickers
- ALL time inputs use `buildTimePick(id, h, m)` — two selects (hour 0-23, min 00/15/30/45)
- Read with `getTimePick(id)` → {h, m}
- NEVER use `<input type="time">` — iOS ignores step="900"

### Break System
- `addBreakAt(dk_, sh, sm)` — dk_ can be null (date picker shown)
- Auto-break after every booking (SETTINGS.breakMinutes, default 15)
- Slot targets rendered LAST in DOM (after booking tiles) so they catch clicks
- z-index: work blocks=1, slot targets=3, bookings=4, breaks=4

### Modals
- `openM(title, body, foot, lg)` — string-based, use for simple content
- For complex/dynamic content: build DOM directly, wire onclick as closures
- NEVER use inline onclick with string-concatenated variables (quote escaping breaks)

### Settings tabs
1. Varausasetukset — cancelHours, breakMinutes, slot unit, reminders
2. Näyttö & Turvallisuus — logo upload, bg image upload, Stripe key, Resend key
3. Aukioloajat — weekly hours grid
4. Lisenssi — key display, per-user pricing (15€ + 25.5% VAT = 18.83€)

### Reports
- CSV exports pull from LIVE BKS/CUSTS arrays (not hardcoded)
- Email designer for pre/post-visit reminders

## Key Rules
1. Validate JS syntax after EVERY change before declaring done
2. Never change fonts, colours, or design tokens
3. Never use innerHTML with string-concatenated JS variables for event handlers
4. Slot click targets must be appended LAST in the DOM column
5. All Finnish text must use proper ä, ö characters
6. Admin = blue; Client = violet-to-blue gradient
7. Time pickers: always buildTimePick(), never input[type=time]

## Production Roadmap (not yet built)
1. Backend: Node.js + Supabase (bookings table, auth, row-level security)
2. License server: POST /api/v1/license/validate — domain-locked JWT
3. Email: Resend API (sendEmail stub already in place)
4. Payments: Stripe (key field in settings, UI stub done)
5. Auth: Supabase auth replacing the current no-auth admin

## What's Working in the Preview
- Real slot engine: availability = WBS minus BKS minus BREAKS
- Client → Admin bridge: client bookings appear in admin calendar immediately
- Multi-location support in client flow
- Photo uploads (iOS/Android camera roll)
- CSV exports from live data
- AI chat (demo mode, Anthropic API ready)
- Break system: click slot, auto-break after booking, break tiles in calendar
- Custom 15-min time pickers on all modals
- Privacy mode (initials only)
- Payment modal inline (Kortti/Käteinen/Stripe stub)
- License tab with VAT pricing

## Known Limitations (demo only)
- No persistence — resets on page refresh
- Email/SMS are console stubs
- Stripe not connected
- License validation is client-side stub
- Calendar hardcoded to March/April 2026 range
